import React, { Component } from 'react';
import {BrowserRouter , Route, Switch} from 'react-router-dom';
import AllUsers from './AllUsers/AllUsers';
import RegForm from './RegForm/RegForm';

class App extends Component {

  render(){
    return(
        <BrowserRouter>
          <div>
            <Switch>
              <Route exact path="/editUser/:id" component={RegForm} />
              <Route exact path="/addUser" component={RegForm}/>
              <Route path="/" component={AllUsers} />
            </Switch>
          </div>
        </BrowserRouter>
    );
  }
}


export default App;
