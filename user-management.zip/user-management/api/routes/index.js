var express = require('express');
var router = express.Router();
var cors = require('cors');
var app = express();
app.use(cors());
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Hello World' });
});



router.get('/data', (req, res)=>{

  const object = {
    name : 'Shailly Jain',
    email : 'shaillyjain8279@gmail.com'
  }
  res.json(object);
});
module.exports = router;
